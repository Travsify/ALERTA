This folder contains all Laravel framework files.
Upload this entire folder to your hosting root directory (one level above public_html).
